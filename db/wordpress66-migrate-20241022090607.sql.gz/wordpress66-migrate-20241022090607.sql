# WordPress MySQL database migration
#
# Generated: Tuesday 22. October 2024 09:06 UTC
# Hostname: localhost
# Database: `wordpress-6-6`
# URL: //localhost/wordpress-6.6.2
# Path: C:\\xampp\\htdocs\\wordpress-6.6.2
# Tables: wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, attachment, page, post, wp_global_styles, wp_navigation
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT 0,
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2024-10-22 05:21:26', '2024-10-22 05:21:26', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://en.gravatar.com/">Gravatar</a>.', 0, '1', '', 'comment', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT 1,
  `link_rating` int(11) NOT NULL DEFAULT 0,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=242 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'cron', 'a:10:{i:1729588886;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1729617694;a:1:{s:21:"wp_update_user_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1729621286;a:1:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1729623086;a:1:{s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1729624886;a:1:{s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1729660886;a:2:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1729660894;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1729660899;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1730180544;a:1:{s:30:"wp_delete_temp_updater_backups";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'auto'),
(2, 'siteurl', 'http://localhost/wordpress-6.6.2', 'on'),
(3, 'home', 'http://localhost/wordpress-6.6.2', 'on'),
(4, 'blogname', 'WordPress 6-6', 'on'),
(5, 'blogdescription', '', 'on'),
(6, 'users_can_register', '0', 'on'),
(7, 'admin_email', 'ckvaghela92@gmail.com', 'on'),
(8, 'start_of_week', '1', 'on'),
(9, 'use_balanceTags', '0', 'on'),
(10, 'use_smilies', '1', 'on'),
(11, 'require_name_email', '1', 'on'),
(12, 'comments_notify', '1', 'on'),
(13, 'posts_per_rss', '10', 'on'),
(14, 'rss_use_excerpt', '0', 'on'),
(15, 'mailserver_url', 'mail.example.com', 'on'),
(16, 'mailserver_login', 'login@example.com', 'on'),
(17, 'mailserver_pass', 'password', 'on'),
(18, 'mailserver_port', '110', 'on'),
(19, 'default_category', '1', 'on'),
(20, 'default_comment_status', 'open', 'on'),
(21, 'default_ping_status', 'open', 'on'),
(22, 'default_pingback_flag', '0', 'on'),
(23, 'posts_per_page', '10', 'on'),
(24, 'date_format', 'F j, Y', 'on'),
(25, 'time_format', 'g:i a', 'on'),
(26, 'links_updated_date_format', 'F j, Y g:i a', 'on'),
(27, 'comment_moderation', '0', 'on'),
(28, 'moderation_notify', '1', 'on'),
(29, 'permalink_structure', '/%postname%/', 'on'),
(30, 'rewrite_rules', 'a:91:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'on'),
(31, 'hack_file', '0', 'on'),
(32, 'blog_charset', 'UTF-8', 'on'),
(33, 'moderation_keys', '', 'off'),
(34, 'active_plugins', 'a:3:{i:0;s:33:"classic-editor/classic-editor.php";i:1;s:33:"featured-posts/featured-posts.php";i:2;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'on'),
(35, 'category_base', '', 'on'),
(36, 'ping_sites', 'http://rpc.pingomatic.com/', 'on'),
(37, 'comment_max_links', '2', 'on'),
(38, 'gmt_offset', '0', 'on'),
(39, 'default_email_category', '1', 'on'),
(40, 'recently_edited', '', 'off'),
(41, 'template', 'twentytwentyfour', 'on'),
(42, 'stylesheet', 'twentytwentyfour', 'on'),
(43, 'comment_registration', '0', 'on'),
(44, 'html_type', 'text/html', 'on'),
(45, 'use_trackback', '0', 'on'),
(46, 'default_role', 'subscriber', 'on'),
(47, 'db_version', '57155', 'on'),
(48, 'uploads_use_yearmonth_folders', '1', 'on'),
(49, 'upload_path', '', 'on'),
(50, 'blog_public', '0', 'on'),
(51, 'default_link_category', '2', 'on'),
(52, 'show_on_front', 'posts', 'on'),
(53, 'tag_base', '', 'on'),
(54, 'show_avatars', '1', 'on'),
(55, 'avatar_rating', 'G', 'on'),
(56, 'upload_url_path', '', 'on'),
(57, 'thumbnail_size_w', '150', 'on'),
(58, 'thumbnail_size_h', '150', 'on'),
(59, 'thumbnail_crop', '1', 'on'),
(60, 'medium_size_w', '300', 'on'),
(61, 'medium_size_h', '300', 'on'),
(62, 'avatar_default', 'mystery', 'on'),
(63, 'large_size_w', '1024', 'on'),
(64, 'large_size_h', '1024', 'on'),
(65, 'image_default_link_type', 'none', 'on'),
(66, 'image_default_size', '', 'on'),
(67, 'image_default_align', '', 'on'),
(68, 'close_comments_for_old_posts', '0', 'on'),
(69, 'close_comments_days_old', '14', 'on'),
(70, 'thread_comments', '1', 'on'),
(71, 'thread_comments_depth', '5', 'on'),
(72, 'page_comments', '0', 'on'),
(73, 'comments_per_page', '50', 'on'),
(74, 'default_comments_page', 'newest', 'on'),
(75, 'comment_order', 'asc', 'on'),
(76, 'sticky_posts', 'a:0:{}', 'on'),
(77, 'widget_categories', 'a:0:{}', 'on'),
(78, 'widget_text', 'a:0:{}', 'on'),
(79, 'widget_rss', 'a:0:{}', 'on'),
(80, 'uninstall_plugins', 'a:0:{}', 'off'),
(81, 'timezone_string', '', 'on'),
(82, 'page_for_posts', '0', 'on'),
(83, 'page_on_front', '0', 'on'),
(84, 'default_post_format', '0', 'on'),
(85, 'link_manager_enabled', '0', 'on'),
(86, 'finished_splitting_shared_terms', '1', 'on'),
(87, 'site_icon', '0', 'on'),
(88, 'medium_large_size_w', '768', 'on'),
(89, 'medium_large_size_h', '0', 'on'),
(90, 'wp_page_for_privacy_policy', '3', 'on'),
(91, 'show_comments_cookies_opt_in', '1', 'on'),
(92, 'admin_email_lifespan', '1745126486', 'on'),
(93, 'disallowed_keys', '', 'off'),
(94, 'comment_previously_approved', '1', 'on'),
(95, 'auto_plugin_theme_update_emails', 'a:0:{}', 'off'),
(96, 'auto_update_core_dev', 'enabled', 'on'),
(97, 'auto_update_core_minor', 'enabled', 'on'),
(98, 'auto_update_core_major', 'enabled', 'on'),
(99, 'wp_force_deactivated_plugins', 'a:0:{}', 'on'),
(100, 'wp_attachment_pages_enabled', '0', 'on') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'initial_db_version', '57155', 'on'),
(102, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'auto'),
(103, 'fresh_site', '0', 'auto'),
(104, 'user_count', '1', 'off'),
(105, 'widget_block', 'a:6:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:154:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Posts</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:227:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Comments</h2><!-- /wp:heading --><!-- wp:latest-comments {"displayAvatar":false,"displayDate":false,"displayExcerpt":false} /--></div><!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:146:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Archives</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:150:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Categories</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->";}s:12:"_multiwidget";i:1;}', 'auto'),
(106, 'sidebars_widgets', 'a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}s:13:"array_version";i:3;}', 'auto'),
(107, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(108, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(109, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(110, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(111, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(112, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(113, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(114, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(115, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(116, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(117, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(118, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(119, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(120, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(125, 'recovery_keys', 'a:0:{}', 'auto'),
(126, 'theme_mods_twentytwentyfour', 'a:1:{s:18:"custom_css_post_id";i:-1;}', 'auto'),
(137, 'can_compress_scripts', '1', 'on'),
(151, 'recently_activated', 'a:0:{}', 'auto'),
(154, 'finished_updating_comment_type', '1', 'auto'),
(175, 'wp_calendar_block_has_published_posts', '1', 'auto'),
(194, 'category_children', 'a:0:{}', 'auto'),
(204, 'show_featured_posts', '3', 'auto'),
(207, 'show_posts_on_scroll', '2', 'auto'),
(241, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1729587967;}', 'off') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(5, 7, '_edit_lock', '1729579357:1'),
(6, 7, '_edit_last', '1'),
(7, 7, '_wp_page_template', 'featured-posts-public'),
(8, 1, '_edit_lock', '1729577554:1'),
(9, 1, '_edit_last', '1'),
(10, 1, '_wp_page_template', 'default'),
(12, 1, '_wp_old_slug', 'hello-world'),
(13, 12, '_edit_last', '1'),
(14, 12, '_edit_lock', '1729577419:1'),
(15, 12, '_wp_page_template', 'default'),
(17, 14, '_edit_last', '1'),
(18, 14, '_edit_lock', '1729577570:1'),
(19, 14, '_wp_page_template', 'default'),
(23, 18, '_edit_last', '1'),
(24, 18, '_edit_lock', '1729577216:1'),
(25, 18, '_wp_page_template', 'default'),
(27, 20, '_edit_last', '1'),
(28, 20, '_edit_lock', '1729577117:1'),
(29, 20, '_wp_page_template', 'default'),
(31, 22, '_edit_last', '1'),
(32, 22, '_edit_lock', '1729577216:1'),
(33, 22, '_wp_page_template', 'default'),
(35, 24, '_edit_last', '1'),
(36, 24, '_edit_lock', '1729577216:1'),
(37, 24, '_wp_page_template', 'default'),
(39, 26, '_edit_last', '1'),
(40, 26, '_edit_lock', '1729577215:1'),
(41, 26, '_wp_page_template', 'default'),
(43, 28, '_wp_attached_file', '2024/10/post-7.webp'),
(44, 28, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1276;s:6:"height";i:717;s:4:"file";s:19:"2024/10/post-7.webp";s:8:"filesize";i:56290;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:19:"post-7-300x169.webp";s:5:"width";i:300;s:6:"height";i:169;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:12234;}s:5:"large";a:5:{s:4:"file";s:20:"post-7-1024x575.webp";s:5:"width";i:1024;s:6:"height";i:575;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:63918;}s:9:"thumbnail";a:5:{s:4:"file";s:19:"post-7-150x150.webp";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:6234;}s:12:"medium_large";a:5:{s:4:"file";s:19:"post-7-768x432.webp";s:5:"width";i:768;s:6:"height";i:432;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:43738;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(45, 29, '_wp_attached_file', '2024/10/post-6.webp'),
(46, 29, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1344;s:6:"height";i:710;s:4:"file";s:19:"2024/10/post-6.webp";s:8:"filesize";i:131830;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:19:"post-6-300x158.webp";s:5:"width";i:300;s:6:"height";i:158;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:15988;}s:5:"large";a:5:{s:4:"file";s:20:"post-6-1024x541.webp";s:5:"width";i:1024;s:6:"height";i:541;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:127598;}s:9:"thumbnail";a:5:{s:4:"file";s:19:"post-6-150x150.webp";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:8334;}s:12:"medium_large";a:5:{s:4:"file";s:19:"post-6-768x406.webp";s:5:"width";i:768;s:6:"height";i:406;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:79908;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(47, 30, '_wp_attached_file', '2024/10/post-5.jpg'),
(48, 30, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1016;s:6:"height";i:647;s:4:"file";s:18:"2024/10/post-5.jpg";s:8:"filesize";i:175020;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:18:"post-5-300x191.jpg";s:5:"width";i:300;s:6:"height";i:191;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:21787;}s:9:"thumbnail";a:5:{s:4:"file";s:18:"post-5-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9277;}s:12:"medium_large";a:5:{s:4:"file";s:18:"post-5-768x489.jpg";s:5:"width";i:768;s:6:"height";i:489;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:121151;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:38:"Ñåðãåé Ôàäåè÷åâ/ÒÀÑÑ";s:6:"camera";s:0:"";s:7:"caption";s:223:"MOSCOW, RUSSIA - JUNE 7, 2018: A train at Kiyevsky Railway Station. Sergei Fadeichev/TASS\n\nÐîññèÿ. Ìîñêâà. Ïîåçä íà ïåððîíå Êèåâñêîãî âîêçàëà. Ñåðãåé Ôàäåè÷åâ/ÒÀÑÑ";s:17:"created_timestamp";s:10:"1528378915";s:9:"copyright";s:30:"2018 TASS, all rights reserved";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:34:"Kiyevsky Railway Station in Moscow";s:11:"orientation";s:1:"0";s:8:"keywords";a:9:{i:0;s:8:"platform";i:1;s:8:"terminal";i:2;s:4:"rail";i:3;s:7:"railway";i:4;s:30:"æåëåçíîäîðîæíûé";i:5;s:6:"ðæä";i:6;s:12:"âîêçàë";i:7;s:7:"Kievsky";i:8;s:9:"transport";}}}'),
(49, 31, '_wp_attached_file', '2024/10/post-4.webp'),
(50, 31, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1600;s:6:"height";i:1122;s:4:"file";s:19:"2024/10/post-4.webp";s:8:"filesize";i:204966;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:19:"post-4-300x210.webp";s:5:"width";i:300;s:6:"height";i:210;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:16120;}s:5:"large";a:5:{s:4:"file";s:20:"post-4-1024x718.webp";s:5:"width";i:1024;s:6:"height";i:718;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:115264;}s:9:"thumbnail";a:5:{s:4:"file";s:19:"post-4-150x150.webp";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:7566;}s:12:"medium_large";a:5:{s:4:"file";s:19:"post-4-768x539.webp";s:5:"width";i:768;s:6:"height";i:539;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:74360;}s:9:"1536x1536";a:5:{s:4:"file";s:21:"post-4-1536x1077.webp";s:5:"width";i:1536;s:6:"height";i:1077;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:197732;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(51, 32, '_wp_attached_file', '2024/10/post-3.webp'),
(52, 32, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1600;s:6:"height";i:1065;s:4:"file";s:19:"2024/10/post-3.webp";s:8:"filesize";i:298504;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:19:"post-3-300x200.webp";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:16772;}s:5:"large";a:5:{s:4:"file";s:20:"post-3-1024x682.webp";s:5:"width";i:1024;s:6:"height";i:682;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:158600;}s:9:"thumbnail";a:5:{s:4:"file";s:19:"post-3-150x150.webp";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:7466;}s:12:"medium_large";a:5:{s:4:"file";s:19:"post-3-768x511.webp";s:5:"width";i:768;s:6:"height";i:511;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:95586;}s:9:"1536x1536";a:5:{s:4:"file";s:21:"post-3-1536x1022.webp";s:5:"width";i:1536;s:6:"height";i:1022;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:290748;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(53, 33, '_wp_attached_file', '2024/10/post-2.webp'),
(54, 33, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1600;s:6:"height";i:1056;s:4:"file";s:19:"2024/10/post-2.webp";s:8:"filesize";i:208728;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:19:"post-2-300x198.webp";s:5:"width";i:300;s:6:"height";i:198;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:17230;}s:5:"large";a:5:{s:4:"file";s:20:"post-2-1024x676.webp";s:5:"width";i:1024;s:6:"height";i:676;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:116070;}s:9:"thumbnail";a:5:{s:4:"file";s:19:"post-2-150x150.webp";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:7128;}s:12:"medium_large";a:5:{s:4:"file";s:19:"post-2-768x507.webp";s:5:"width";i:768;s:6:"height";i:507;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:76104;}s:9:"1536x1536";a:5:{s:4:"file";s:21:"post-2-1536x1014.webp";s:5:"width";i:1536;s:6:"height";i:1014;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:195996;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(55, 34, '_wp_attached_file', '2024/10/post-1.webp'),
(56, 34, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1160;s:6:"height";i:653;s:4:"file";s:19:"2024/10/post-1.webp";s:8:"filesize";i:101946;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:19:"post-1-300x169.webp";s:5:"width";i:300;s:6:"height";i:169;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:10974;}s:5:"large";a:5:{s:4:"file";s:20:"post-1-1024x576.webp";s:5:"width";i:1024;s:6:"height";i:576;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:72410;}s:9:"thumbnail";a:5:{s:4:"file";s:19:"post-1-150x150.webp";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:5756;}s:12:"medium_large";a:5:{s:4:"file";s:19:"post-1-768x432.webp";s:5:"width";i:768;s:6:"height";i:432;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:48026;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(57, 26, '_thumbnail_id', '34'),
(59, 24, '_thumbnail_id', '33'),
(61, 22, '_thumbnail_id', '32'),
(63, 20, '_thumbnail_id', '31'),
(65, 18, '_thumbnail_id', '30'),
(67, 14, '_thumbnail_id', '29'),
(69, 12, '_thumbnail_id', '28'),
(71, 35, '_wp_attached_file', '2024/10/post-8.jpg'),
(72, 35, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1024;s:6:"height";i:683;s:4:"file";s:18:"2024/10/post-8.jpg";s:8:"filesize";i:138104;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:18:"post-8-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:18442;}s:9:"thumbnail";a:5:{s:4:"file";s:18:"post-8-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7847;}s:12:"medium_large";a:5:{s:4:"file";s:18:"post-8-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:97489;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(73, 1, '_thumbnail_id', '35') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT 0,
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT 0,
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2024-10-22 05:21:26', '2024-10-22 05:21:26', 'влияют на доходность добычи биткоина Выгода от майнинга биткоина непостоянна и сильно отличается во времени. Иногда это делать рентабельно, а иногда - убыточно. Какие именно факторы оказывают • влияние на добычу биткоина? Чем вызвана популярность • майнинга Новые монеты ВТС поступают в обращение благодаря майнингу. За счет влияют на доходность добычи биткоина Выгода от майнинга биткоина непостоянна и сильно отличается во времени. Иногда это делать рентабельно, а иногда - убыточно. Какие именно факторы оказывают • влияние на добычу биткоина? Чем вызвана популярность • майнинга Новые монеты ВТС поступают в обращение благодаря майнингу. За счет.', '2 - Подходящий момент для майнинга: какие факторы влияют на доходность добычи биткоина', '', 'publish', 'open', 'open', '', '2-%d0%bf%d0%be%d0%b4%d1%85%d0%be%d0%b4%d1%8f%d1%89%d0%b8%d0%b9-%d0%bc%d0%be%d0%bc%d0%b5%d0%bd%d1%82-%d0%b4%d0%bb%d1%8f-%d0%bc%d0%b0%d0%b9%d0%bd%d0%b8%d0%bd%d0%b3%d0%b0-%d0%ba%d0%b0%d0%ba%d0%b8', '', '', '2024-10-22 06:12:34', '2024-10-22 06:12:34', '', 0, 'http://localhost/wordpress-6.6.2/?p=1', 0, 'post', '', 1),
(2, 1, '2024-10-22 05:21:26', '2024-10-22 05:21:26', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href="http://localhost/wordpress-6.6.2/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2024-10-22 05:21:26', '2024-10-22 05:21:26', '', 0, 'http://localhost/wordpress-6.6.2/?page_id=2', 0, 'page', '', 0),
(3, 1, '2024-10-22 05:21:26', '2024-10-22 05:21:26', '<!-- wp:heading -->\n<h2 class="wp-block-heading">Who we are</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>Our website address is: http://localhost/wordpress-6.6.2.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Comments</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Media</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Cookies</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Embedded content from other websites</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Who we share your data with</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">How long we retain your data</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">What rights you have over your data</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Where your data is sent</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p>\n<!-- /wp:paragraph -->\n', 'Privacy Policy', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2024-10-22 05:21:26', '2024-10-22 05:21:26', '', 0, 'http://localhost/wordpress-6.6.2/?page_id=3', 0, 'page', '', 0),
(4, 0, '2024-10-22 05:21:27', '2024-10-22 05:21:27', '<!-- wp:page-list /-->', 'Navigation', '', 'publish', 'closed', 'closed', '', 'navigation', '', '', '2024-10-22 05:21:27', '2024-10-22 05:21:27', '', 0, 'http://localhost/wordpress-6.6.2/2024/10/22/navigation/', 0, 'wp_navigation', '', 0),
(5, 1, '2024-10-22 05:21:39', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2024-10-22 05:21:39', '0000-00-00 00:00:00', '', 0, 'http://localhost/wordpress-6.6.2/?p=5', 0, 'post', '', 0),
(7, 1, '2024-10-22 05:52:24', '2024-10-22 05:52:24', '', 'Featured Posts', '', 'publish', 'closed', 'closed', '', 'featured-posts', '', '', '2024-10-22 06:34:17', '2024-10-22 06:34:17', '', 0, 'http://localhost/wordpress-6.6.2/?page_id=7', 0, 'page', '', 0),
(8, 1, '2024-10-22 05:52:02', '2024-10-22 05:52:02', '{"version":3,"isGlobalStylesUserThemeJSON":true}', 'Custom Styles', '', 'publish', 'closed', 'closed', '', 'wp-global-styles-twentytwentyfour', '', '', '2024-10-22 05:52:02', '2024-10-22 05:52:02', '', 0, 'http://localhost/wordpress-6.6.2/2024/10/22/wp-global-styles-twentytwentyfour/', 0, 'wp_global_styles', '', 0),
(9, 1, '2024-10-22 05:52:24', '2024-10-22 05:52:24', '', 'Featured Posts', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2024-10-22 05:52:24', '2024-10-22 05:52:24', '', 7, 'http://localhost/wordpress-6.6.2/?p=9', 0, 'revision', '', 0),
(10, 1, '2024-10-22 05:56:02', '2024-10-22 05:56:02', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', '2 - Подходящий момент для майнинга: какие факторы влияют на доходность добычи биткоина', '', 'inherit', 'closed', 'closed', '', '1-autosave-v1', '', '', '2024-10-22 05:56:02', '2024-10-22 05:56:02', '', 1, 'http://localhost/wordpress-6.6.2/?p=10', 0, 'revision', '', 0),
(11, 1, '2024-10-22 05:56:36', '2024-10-22 05:56:36', '<p>влияют на доходность добычи биткоина Выгода от майнинга биткоина непостоянна и сильно отличается во времени. Иногда это делать рентабельно, а иногда - убыточно. Какие именно факторы оказывают • влияние на добычу биткоина? Чем вызвана популярность • майнинга Новые монеты ВТС поступают в обращение благодаря майнингу. За счет...</p>', '2 - Подходящий момент для майнинга: какие факторы влияют на доходность добычи биткоина', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2024-10-22 05:56:36', '2024-10-22 05:56:36', '', 1, 'http://localhost/wordpress-6.6.2/?p=11', 0, 'revision', '', 0),
(12, 1, '2024-10-22 05:57:04', '2024-10-22 05:57:04', 'Прочее forklog com 8 ч Время прочтения: ~2 м Власти Бали решили бороться с криптовалютами в туристическом секторе, журналисты раскрыли детали отчета о взломе Bitfinex, доход биткоин-майнеров в мае превысил $900 млн и другие события уходящей недели. Соглашение о потолке госдолга Прочее forklog com 8 ч Время прочтения: ~2 м Власти Бали решили бороться с криптовалютами в туристическом секторе, журналисты раскрыли детали отчета о взломе Bitfinex, доход биткоин-майнеров в мае превысил $900 млн и другие события уходящей недели. Соглашение о потолке госдолга.', '8 - Итоги недели: власти Бали объявили о борьбе с криптовалютами, а доход биткоин-майнеров в мае превысил $900 млн', '', 'publish', 'open', 'open', '', '8-%d0%b8%d1%82%d0%be%d0%b3%d0%b8-%d0%bd%d0%b5%d0%b4%d0%b5%d0%bb%d0%b8-%d0%b2%d0%bb%d0%b0%d1%81%d1%82%d0%b8-%d0%b1%d0%b0%d0%bb%d0%b8-%d0%be%d0%b1%d1%8a%d1%8f%d0%b2%d0%b8%d0%bb%d0%b8-%d0%be-%d0%b1', '', '', '2024-10-22 06:12:41', '2024-10-22 06:12:41', '', 0, 'http://localhost/wordpress-6.6.2/?p=12', 0, 'post', '', 0),
(13, 1, '2024-10-22 05:57:04', '2024-10-22 05:57:04', 'Прочее forklog com 8 ч Время прочтения: ~2 м Власти Бали решили бороться с криптовалютами в туристическом секторе, журналисты раскрыли детали отчета о взломе Bitfinex, доход биткоин-майнеров в мае превысил $900 млн и другие события уходящей недели. Соглашение о потолке госдолга..', '8 - Итоги недели: власти Бали объявили о борьбе с криптовалютами, а доход биткоин-майнеров в мае превысил $900 млн', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2024-10-22 05:57:04', '2024-10-22 05:57:04', '', 12, 'http://localhost/wordpress-6.6.2/?p=13', 0, 'revision', '', 0),
(14, 1, '2024-10-22 05:57:32', '2024-10-22 05:57:32', 'Крупнейшая криптобиржа мира объявила, что гордится своей помощью, оказанной правоохранителям из США в деле ареста и заморозки связанных с хакерами из Северной Кореи счетов с активами на миллионы долларов. «Мы стремимся поддерживать власти в выявлении злоумышленников и предотвращении преступлений»\r\n\r\nКрупнейшая криптобиржа мира объявила, что гордится своей помощью, оказанной правоохранителям из США в деле ареста и заморозки связанных с хакерами из Северной Кореи счетов с активами на миллионы долларов. «Мы стремимся поддерживать власти в выявлении злоумышленников и предотвращении преступлений»,', '9 - Binance: Мы рады помогать США бороться с северокорейскими криптохакерами', '', 'publish', 'open', 'open', '', '9-binance-%d0%bc%d1%8b-%d1%80%d0%b0%d0%b4%d1%8b-%d0%bf%d0%be%d0%bc%d0%be%d0%b3%d0%b0%d1%82%d1%8c-%d1%81%d1%88%d0%b0-%d0%b1%d0%be%d1%80%d0%be%d1%82%d1%8c%d1%81%d1%8f-%d1%81-%d1%81%d0%b5%d0%b2%d0%b5', '', '', '2024-10-22 06:12:50', '2024-10-22 06:12:50', '', 0, 'http://localhost/wordpress-6.6.2/?p=14', 0, 'post', '', 0),
(15, 1, '2024-10-22 05:57:32', '2024-10-22 05:57:32', 'Крупнейшая криптобиржа мира объявила, что гордится своей помощью, оказанной правоохранителям из США в деле ареста и заморозки связанных с хакерами из Северной Кореи счетов с активами на миллионы долларов. «Мы стремимся поддерживать власти в выявлении злоумышленников и предотвращении преступлений»\r\n\r\nКрупнейшая криптобиржа мира объявила, что гордится своей помощью, оказанной правоохранителям из США в деле ареста и заморозки связанных с хакерами из Северной Кореи счетов с активами на миллионы долларов. «Мы стремимся поддерживать власти в выявлении злоумышленников и предотвращении преступлений»,', '9 - Binance: Мы рады помогать США бороться с северокорейскими криптохакерами', '', 'inherit', 'closed', 'closed', '', '14-revision-v1', '', '', '2024-10-22 05:57:32', '2024-10-22 05:57:32', '', 14, 'http://localhost/wordpress-6.6.2/?p=15', 0, 'revision', '', 0),
(16, 1, '2024-10-22 05:57:45', '2024-10-22 05:57:45', 'Прочее forklog com 8 ч Время прочтения: ~2 м Власти Бали решили бороться с криптовалютами в туристическом секторе, журналисты раскрыли детали отчета о взломе Bitfinex, доход биткоин-майнеров в мае превысил $900 млн и другие события уходящей недели. Соглашение о потолке госдолга Прочее forklog com 8 ч Время прочтения: ~2 м Власти Бали решили бороться с криптовалютами в туристическом секторе, журналисты раскрыли детали отчета о взломе Bitfinex, доход биткоин-майнеров в мае превысил $900 млн и другие события уходящей недели. Соглашение о потолке госдолга.', '8 - Итоги недели: власти Бали объявили о борьбе с криптовалютами, а доход биткоин-майнеров в мае превысил $900 млн', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2024-10-22 05:57:45', '2024-10-22 05:57:45', '', 12, 'http://localhost/wordpress-6.6.2/?p=16', 0, 'revision', '', 0),
(17, 1, '2024-10-22 05:58:02', '2024-10-22 05:58:02', 'влияют на доходность добычи биткоина Выгода от майнинга биткоина непостоянна и сильно отличается во времени. Иногда это делать рентабельно, а иногда - убыточно. Какие именно факторы оказывают • влияние на добычу биткоина? Чем вызвана популярность • майнинга Новые монеты ВТС поступают в обращение благодаря майнингу. За счет влияют на доходность добычи биткоина Выгода от майнинга биткоина непостоянна и сильно отличается во времени. Иногда это делать рентабельно, а иногда - убыточно. Какие именно факторы оказывают • влияние на добычу биткоина? Чем вызвана популярность • майнинга Новые монеты ВТС поступают в обращение благодаря майнингу. За счет.', '2 - Подходящий момент для майнинга: какие факторы влияют на доходность добычи биткоина', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2024-10-22 05:58:02', '2024-10-22 05:58:02', '', 1, 'http://localhost/wordpress-6.6.2/?p=17', 0, 'revision', '', 0),
(18, 1, '2024-10-22 05:58:21', '2024-10-22 05:58:21', 'Безопасность асryptoinvest.news 1 ч Время прочтения: ~2 м Фирма по управлению рисками криптовалюты Elliptic интегрировала ChatGPT, чтобы повысить эффективность обнаружения крипто-угроз, что связано с тем, что другие крипто- фирмы сообщают о неоднозначных результатах его внедрения. Elliptic предоставляет пользователям криптовалют оценку рисков Безопасность асryptoinvest.news 1 ч Время прочтения: ~2 м Фирма по управлению рисками криптовалюты Elliptic интегрировала ChatGPT, чтобы повысить эффективность обнаружения крипто-угроз, что связано с тем, что другие крипто- фирмы сообщают о неоднозначных результатах его внедрения. Elliptic предоставляет пользователям криптовалют оценку рисков', '1 - Elliptic интегрирует ChatGPT для обнаружения крипто- РИСКОВ', '', 'publish', 'open', 'open', '', '1-elliptic-%d0%b8%d0%bd%d1%82%d0%b5%d0%b3%d1%80%d0%b8%d1%80%d1%83%d0%b5%d1%82-chatgpt-%d0%b4%d0%bb%d1%8f-%d0%be%d0%b1%d0%bd%d0%b0%d1%80%d1%83%d0%b6%d0%b5%d0%bd%d0%b8%d1%8f-%d0%ba%d1%80%d0%b8%d0%bf', '', '', '2024-10-22 06:07:45', '2024-10-22 06:07:45', '', 0, 'http://localhost/wordpress-6.6.2/?p=18', 0, 'post', '', 0),
(19, 1, '2024-10-22 05:58:21', '2024-10-22 05:58:21', 'Безопасность асryptoinvest.news 1 ч Время прочтения: ~2 м Фирма по управлению рисками криптовалюты Elliptic интегрировала ChatGPT, чтобы повысить эффективность обнаружения крипто-угроз, что связано с тем, что другие крипто- фирмы сообщают о неоднозначных результатах его внедрения. Elliptic предоставляет пользователям криптовалют оценку рисков Безопасность асryptoinvest.news 1 ч Время прочтения: ~2 м Фирма по управлению рисками криптовалюты Elliptic интегрировала ChatGPT, чтобы повысить эффективность обнаружения крипто-угроз, что связано с тем, что другие крипто- фирмы сообщают о неоднозначных результатах его внедрения. Elliptic предоставляет пользователям криптовалют оценку рисков', '1 - Elliptic интегрирует ChatGPT для обнаружения крипто- РИСКОВ', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2024-10-22 05:58:21', '2024-10-22 05:58:21', '', 18, 'http://localhost/wordpress-6.6.2/?p=19', 0, 'revision', '', 0),
(20, 1, '2024-10-22 05:58:45', '2024-10-22 05:58:45', 'Альткоины beincrypto.ru 1 ч Время прочтения: ~2 м В 2021 году Китай полностью запретил все криптовалютные операции, и находящийся под его суверенитетом Гонконг ожидаемо попал под эти ограничения. Однако через несколько лет в страну пришла долгожданная криптооттепель: в феврале 2023 Альткоины beincrypto.ru 1 ч Время прочтения: ~2 м В 2021 году Китай полностью запретил все криптовалютные операции, и находящийся под его суверенитетом Гонконг ожидаемо попал под эти ограничения. Однако через несколько лет в страну пришла долгожданная криптооттепель: в феврале 2023', '3 - альткоинов, которые интересны китайским', '', 'publish', 'open', 'open', '', '3-%d0%b0%d0%bb%d1%8c%d1%82%d0%ba%d0%be%d0%b8%d0%bd%d0%be%d0%b2-%d0%ba%d0%be%d1%82%d0%be%d1%80%d1%8b%d0%b5-%d0%b8%d0%bd%d1%82%d0%b5%d1%80%d0%b5%d1%81%d0%bd%d1%8b-%d0%ba%d0%b8%d1%82%d0%b0%d0%b9%d1%81', '', '', '2024-10-22 06:07:24', '2024-10-22 06:07:24', '', 0, 'http://localhost/wordpress-6.6.2/?p=20', 0, 'post', '', 0),
(21, 1, '2024-10-22 05:58:45', '2024-10-22 05:58:45', 'Альткоины beincrypto.ru 1 ч Время прочтения: ~2 м В 2021 году Китай полностью запретил все криптовалютные операции, и находящийся под его суверенитетом Гонконг ожидаемо попал под эти ограничения. Однако через несколько лет в страну пришла долгожданная криптооттепель: в феврале 2023 Альткоины beincrypto.ru 1 ч Время прочтения: ~2 м В 2021 году Китай полностью запретил все криптовалютные операции, и находящийся под его суверенитетом Гонконг ожидаемо попал под эти ограничения. Однако через несколько лет в страну пришла долгожданная криптооттепель: в феврале 2023', '3 - альткоинов, которые интересны китайским', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2024-10-22 05:58:45', '2024-10-22 05:58:45', '', 20, 'http://localhost/wordpress-6.6.2/?p=21', 0, 'revision', '', 0),
(22, 1, '2024-10-22 05:59:17', '2024-10-22 05:59:17', 'Альткоины beincrypto.ru 1 ч Время прочтения: ~2 м В 2021 году Китай полностью запретил все криптовалютные операции, и находящийся под его суверенитетом Гонконг ожидаемо попал под эти ограничения. Однако через несколько лет в страну пришла долгожданная криптооттепель: в феврале 2023 Альткоины beincrypto.ru 1 ч Время прочтения: ~2 м В 2021 году Китай полностью запретил все криптовалютные операции, и находящийся под его суверенитетом Гонконг ожидаемо попал под эти ограничения. Однако через несколько лет в страну пришла долгожданная криптооттепель: в феврале 2023\r\n\r\nАльткоины beincrypto.ru 1 ч Время прочтения: ~2 м В 2021 году Китай полностью запретил все криптовалютные операции, и находящийся под его суверенитетом Гонконг ожидаемо попал под эти ограничения. Однако через несколько лет в страну пришла долгожданная криптооттепель: в феврале 2023 Альткоины beincrypto.ru 1 ч Время прочтения: ~2 м В 2021 году Китай полностью запретил все криптовалютные операции, и находящийся под его суверенитетом Гонконг ожидаемо попал под эти ограничения. Однако через несколько лет в страну пришла долгожданная криптооттепель: в феврале 2023', '4 - альткоинов, которые интересны китайским', '', 'publish', 'open', 'open', '', '4-%d0%b0%d0%bb%d1%8c%d1%82%d0%ba%d0%be%d0%b8%d0%bd%d0%be%d0%b2-%d0%ba%d0%be%d1%82%d0%be%d1%80%d1%8b%d0%b5-%d0%b8%d0%bd%d1%82%d0%b5%d1%80%d0%b5%d1%81%d0%bd%d1%8b-%d0%ba%d0%b8%d1%82%d0%b0%d0%b9%d1%81', '', '', '2024-10-22 06:07:16', '2024-10-22 06:07:16', '', 0, 'http://localhost/wordpress-6.6.2/?p=22', 0, 'post', '', 0),
(23, 1, '2024-10-22 05:59:17', '2024-10-22 05:59:17', 'Альткоины beincrypto.ru 1 ч Время прочтения: ~2 м В 2021 году Китай полностью запретил все криптовалютные операции, и находящийся под его суверенитетом Гонконг ожидаемо попал под эти ограничения. Однако через несколько лет в страну пришла долгожданная криптооттепель: в феврале 2023 Альткоины beincrypto.ru 1 ч Время прочтения: ~2 м В 2021 году Китай полностью запретил все криптовалютные операции, и находящийся под его суверенитетом Гонконг ожидаемо попал под эти ограничения. Однако через несколько лет в страну пришла долгожданная криптооттепель: в феврале 2023\r\n\r\nАльткоины beincrypto.ru 1 ч Время прочтения: ~2 м В 2021 году Китай полностью запретил все криптовалютные операции, и находящийся под его суверенитетом Гонконг ожидаемо попал под эти ограничения. Однако через несколько лет в страну пришла долгожданная криптооттепель: в феврале 2023 Альткоины beincrypto.ru 1 ч Время прочтения: ~2 м В 2021 году Китай полностью запретил все криптовалютные операции, и находящийся под его суверенитетом Гонконг ожидаемо попал под эти ограничения. Однако через несколько лет в страну пришла долгожданная криптооттепель: в феврале 2023', '4 - альткоинов, которые интересны китайским', '', 'inherit', 'closed', 'closed', '', '22-revision-v1', '', '', '2024-10-22 05:59:17', '2024-10-22 05:59:17', '', 22, 'http://localhost/wordpress-6.6.2/?p=23', 0, 'revision', '', 0),
(24, 1, '2024-10-22 05:59:41', '2024-10-22 05:59:41', 'Альткоины beincrypto.ru 1 ч Время прочтения: ~2 м В 2021 году Китай полностью запретил все криптовалютные операции, и находящийся под его суверенитетом Гонконг ожидаемо попал под эти ограничения. Однако через несколько лет в страну пришла долгожданная криптооттепель: в феврале 2023 Альткоины beincrypto.ru 1 ч Время прочтения: ~2 м В 2021 году Китай полностью запретил все криптовалютные операции, и находящийся под его суверенитетом Гонконг ожидаемо попал под эти ограничения. Однако через несколько лет в страну пришла долгожданная криптооттепель: в феврале 2023\r\n\r\nАльткоины beincrypto.ru 1 ч Время прочтения: ~2 м В 2021 году Китай полностью запретил все криптовалютные операции, и находящийся под его суверенитетом Гонконг ожидаемо попал под эти ограничения. Однако через несколько лет в страну пришла долгожданная криптооттепель: в феврале 2023 Альткоины beincrypto.ru 1 ч Время прочтения: ~2 м В 2021 году Китай полностью запретил все криптовалютные операции, и находящийся под его суверенитетом Гонконг ожидаемо попал под эти ограничения. Однако через несколько лет в страну пришла долгожданная криптооттепель: в феврале 2023', '5 - альткоинов, которые интересны китайским', '', 'publish', 'open', 'open', '', '5-%d0%b0%d0%bb%d1%8c%d1%82%d0%ba%d0%be%d0%b8%d0%bd%d0%be%d0%b2-%d0%ba%d0%be%d1%82%d0%be%d1%80%d1%8b%d0%b5-%d0%b8%d0%bd%d1%82%d0%b5%d1%80%d0%b5%d1%81%d0%bd%d1%8b-%d0%ba%d0%b8%d1%82%d0%b0%d0%b9%d1%81', '', '', '2024-10-22 06:07:06', '2024-10-22 06:07:06', '', 0, 'http://localhost/wordpress-6.6.2/?p=24', 0, 'post', '', 0),
(25, 1, '2024-10-22 05:59:41', '2024-10-22 05:59:41', 'Альткоины beincrypto.ru 1 ч Время прочтения: ~2 м В 2021 году Китай полностью запретил все криптовалютные операции, и находящийся под его суверенитетом Гонконг ожидаемо попал под эти ограничения. Однако через несколько лет в страну пришла долгожданная криптооттепель: в феврале 2023 Альткоины beincrypto.ru 1 ч Время прочтения: ~2 м В 2021 году Китай полностью запретил все криптовалютные операции, и находящийся под его суверенитетом Гонконг ожидаемо попал под эти ограничения. Однако через несколько лет в страну пришла долгожданная криптооттепель: в феврале 2023\r\n\r\nАльткоины beincrypto.ru 1 ч Время прочтения: ~2 м В 2021 году Китай полностью запретил все криптовалютные операции, и находящийся под его суверенитетом Гонконг ожидаемо попал под эти ограничения. Однако через несколько лет в страну пришла долгожданная криптооттепель: в феврале 2023 Альткоины beincrypto.ru 1 ч Время прочтения: ~2 м В 2021 году Китай полностью запретил все криптовалютные операции, и находящийся под его суверенитетом Гонконг ожидаемо попал под эти ограничения. Однако через несколько лет в страну пришла долгожданная криптооттепель: в феврале 2023', '5 - альткоинов, которые интересны китайским', '', 'inherit', 'closed', 'closed', '', '24-revision-v1', '', '', '2024-10-22 05:59:41', '2024-10-22 05:59:41', '', 24, 'http://localhost/wordpress-6.6.2/?p=25', 0, 'revision', '', 0),
(26, 1, '2024-10-22 06:00:10', '2024-10-22 06:00:10', 'Альткоины beincrypto.ru 1 ч Время прочтения: ~2 м В 2021 году Китай полностью запретил все криптовалютные операции, и находящийся под его суверенитетом Гонконг ожидаемо попал под эти ограничения. Однако через несколько лет в страну пришла долгожданная криптооттепель: в феврале 2023 Альткоины beincrypto.ru 1 ч Время прочтения: ~2 м В 2021 году Китай полностью запретил все криптовалютные операции, и находящийся под его суверенитетом Гонконг ожидаемо попал под эти ограничения. Однако через несколько лет в страну пришла долгожданная криптооттепель: в феврале 2023\r\n\r\nАльткоины beincrypto.ru 1 ч Время прочтения: ~2 м В 2021 году Китай полностью запретил все криптовалютные операции, и находящийся под его суверенитетом Гонконг ожидаемо попал под эти ограничения. Однако через несколько лет в страну пришла долгожданная криптооттепель: в феврале 2023 Альткоины beincrypto.ru 1 ч Время прочтения: ~2 м В 2021 году Китай полностью запретил все криптовалютные операции, и находящийся под его суверенитетом Гонконг ожидаемо попал под эти ограничения. Однако через несколько лет в страну пришла долгожданная криптооттепель: в феврале 2023', '6 - альткоинов, которые интересны китайским', '', 'publish', 'open', 'open', '', '6-%d0%b0%d0%bb%d1%8c%d1%82%d0%ba%d0%be%d0%b8%d0%bd%d0%be%d0%b2-%d0%ba%d0%be%d1%82%d0%be%d1%80%d1%8b%d0%b5-%d0%b8%d0%bd%d1%82%d0%b5%d1%80%d0%b5%d1%81%d0%bd%d1%8b-%d0%ba%d0%b8%d1%82%d0%b0%d0%b9%d1%81', '', '', '2024-10-22 06:06:58', '2024-10-22 06:06:58', '', 0, 'http://localhost/wordpress-6.6.2/?p=26', 0, 'post', '', 0),
(27, 1, '2024-10-22 06:00:10', '2024-10-22 06:00:10', 'Альткоины beincrypto.ru 1 ч Время прочтения: ~2 м В 2021 году Китай полностью запретил все криптовалютные операции, и находящийся под его суверенитетом Гонконг ожидаемо попал под эти ограничения. Однако через несколько лет в страну пришла долгожданная криптооттепель: в феврале 2023 Альткоины beincrypto.ru 1 ч Время прочтения: ~2 м В 2021 году Китай полностью запретил все криптовалютные операции, и находящийся под его суверенитетом Гонконг ожидаемо попал под эти ограничения. Однако через несколько лет в страну пришла долгожданная криптооттепель: в феврале 2023\r\n\r\nАльткоины beincrypto.ru 1 ч Время прочтения: ~2 м В 2021 году Китай полностью запретил все криптовалютные операции, и находящийся под его суверенитетом Гонконг ожидаемо попал под эти ограничения. Однако через несколько лет в страну пришла долгожданная криптооттепель: в феврале 2023 Альткоины beincrypto.ru 1 ч Время прочтения: ~2 м В 2021 году Китай полностью запретил все криптовалютные операции, и находящийся под его суверенитетом Гонконг ожидаемо попал под эти ограничения. Однако через несколько лет в страну пришла долгожданная криптооттепель: в феврале 2023', '6 - альткоинов, которые интересны китайским', '', 'inherit', 'closed', 'closed', '', '26-revision-v1', '', '', '2024-10-22 06:00:10', '2024-10-22 06:00:10', '', 26, 'http://localhost/wordpress-6.6.2/?p=27', 0, 'revision', '', 0),
(28, 1, '2024-10-22 06:06:41', '2024-10-22 06:06:41', '', 'post-7', '', 'inherit', 'open', 'closed', '', 'post-7', '', '', '2024-10-22 06:06:41', '2024-10-22 06:06:41', '', 26, 'http://localhost/wordpress-6.6.2/wp-content/uploads/2024/10/post-7.webp', 0, 'attachment', 'image/webp', 0),
(29, 1, '2024-10-22 06:06:42', '2024-10-22 06:06:42', '', 'post-6', '', 'inherit', 'open', 'closed', '', 'post-6', '', '', '2024-10-22 06:06:42', '2024-10-22 06:06:42', '', 26, 'http://localhost/wordpress-6.6.2/wp-content/uploads/2024/10/post-6.webp', 0, 'attachment', 'image/webp', 0),
(30, 1, '2024-10-22 06:06:42', '2024-10-22 06:06:42', '', 'Kiyevsky Railway Station in Moscow', 'MOSCOW, RUSSIA - JUNE 7, 2018: A train at Kiyevsky Railway Station. Sergei Fadeichev/TASS\n\nÐîññèÿ. Ìîñêâà. Ïîåçä íà ïåððîíå Êèåâñêîãî âîêçàëà. Ñåðãåé Ôàäåè÷åâ/ÒÀÑÑ', 'inherit', 'open', 'closed', '', 'kiyevsky-railway-station-in-moscow', '', '', '2024-10-22 06:06:42', '2024-10-22 06:06:42', '', 26, 'http://localhost/wordpress-6.6.2/wp-content/uploads/2024/10/post-5.jpg', 0, 'attachment', 'image/jpeg', 0),
(31, 1, '2024-10-22 06:06:43', '2024-10-22 06:06:43', '', 'post-4', '', 'inherit', 'open', 'closed', '', 'post-4', '', '', '2024-10-22 06:06:43', '2024-10-22 06:06:43', '', 26, 'http://localhost/wordpress-6.6.2/wp-content/uploads/2024/10/post-4.webp', 0, 'attachment', 'image/webp', 0),
(32, 1, '2024-10-22 06:06:44', '2024-10-22 06:06:44', '', 'post-3', '', 'inherit', 'open', 'closed', '', 'post-3', '', '', '2024-10-22 06:06:44', '2024-10-22 06:06:44', '', 26, 'http://localhost/wordpress-6.6.2/wp-content/uploads/2024/10/post-3.webp', 0, 'attachment', 'image/webp', 0),
(33, 1, '2024-10-22 06:06:45', '2024-10-22 06:06:45', '', 'post-2', '', 'inherit', 'open', 'closed', '', 'post-2', '', '', '2024-10-22 06:06:45', '2024-10-22 06:06:45', '', 26, 'http://localhost/wordpress-6.6.2/wp-content/uploads/2024/10/post-2.webp', 0, 'attachment', 'image/webp', 0),
(34, 1, '2024-10-22 06:06:46', '2024-10-22 06:06:46', '', 'post-1', '', 'inherit', 'open', 'closed', '', 'post-1', '', '', '2024-10-22 06:06:46', '2024-10-22 06:06:46', '', 26, 'http://localhost/wordpress-6.6.2/wp-content/uploads/2024/10/post-1.webp', 0, 'attachment', 'image/webp', 0),
(35, 1, '2024-10-22 06:09:11', '2024-10-22 06:09:11', '', 'post-8', '', 'inherit', 'open', 'closed', '', 'post-8', '', '', '2024-10-22 06:09:11', '2024-10-22 06:09:11', '', 1, 'http://localhost/wordpress-6.6.2/wp-content/uploads/2024/10/post-8.jpg', 0, 'attachment', 'image/jpeg', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 3, 0),
(8, 2, 0),
(12, 3, 0),
(14, 3, 0),
(18, 1, 0),
(20, 1, 0),
(22, 1, 0),
(24, 1, 0),
(26, 1, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 5),
(2, 2, 'wp_theme', '', 0, 1),
(3, 3, 'category', '', 0, 3) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'twentytwentyfour', 'twentytwentyfour', 0),
(3, 'Featured', 'featured', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:1:{s:64:"95a6341dcf668eef3c9c30cbfc224eaa7ab0b5b7a93295788e363feacb817cc4";a:4:{s:10:"expiration";i:1729747293;s:2:"ip";s:3:"::1";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36";s:5:"login";i:1729574493;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '5'),
(18, 1, 'wp_persisted_preferences', 'a:4:{s:14:"core/edit-post";a:2:{s:12:"welcomeGuide";b:0;s:20:"welcomeGuideTemplate";b:0;}s:9:"_modified";s:24:"2024-10-22T05:53:05.748Z";s:4:"core";a:3:{s:10:"openPanels";a:3:{i:0;s:11:"post-status";i:1;s:9:"post-link";i:2;s:8:"template";}s:26:"isComplementaryAreaVisible";b:0;s:11:"pinnedItems";a:1:{s:32:"kadence-control/kadence-controls";b:1;}}s:14:"core/edit-site";a:1:{s:12:"welcomeGuide";b:0;}}'),
(19, 1, 'wp_user-settings', 'editor=tinymce&libraryContent=browse'),
(20, 1, 'wp_user-settings-time', '1729577213') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BUeeYMRT7GQdGUFHt4VOwqES6LmIaU.', 'admin', 'ckvaghela92@gmail.com', 'http://localhost/wordpress-6.6.2', '2024-10-22 05:21:26', '', 0, 'admin') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

